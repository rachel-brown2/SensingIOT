<?php

function getClient()
{
    $client = new Google_Client();
    $client->setApplicationName('Google Sheets API PHP Quickstart');
    $client->setScopes(Google_Service_Sheets::SPREADSHEETS);
    $client->setAuthConfig(__DIR__ .'/credentials.json');
    $client->setAccessType('offline');
    $client->setPrompt('select_account consent');

    $tokenPath = 'token.json';
    if (file_exists($tokenPath)) {
        $accessToken = json_decode(file_get_contents($tokenPath), true);
        $client->setAccessToken($accessToken);
    }

    // If there is no previous token or it's expired.
    if ($client->isAccessTokenExpired()) {
        // Refresh the token if possible, else fetch a new one.
        if ($client->getRefreshToken()) {
            $client->fetchAccessTokenWithRefreshToken($client->getRefreshToken());
        } else {
            // Request authorization from the user.
            $authUrl = $client->createAuthUrl();
            printf("Open the following link in your browser:\n%s\n", $authUrl);
            print 'Enter verification code: ';
            $authCode = trim(fgets(STDIN));

            // Exchange authorization code for an access token.
            $accessToken = $client->fetchAccessTokenWithAuthCode($authCode);
            $client->setAccessToken($accessToken);

            // Check to see if there was an error.
            if (array_key_exists('error', $accessToken)) {
                throw new Exception(join(', ', $accessToken));
            }
        }
        // Save the token to a file.
        if (!file_exists(dirname($tokenPath))) {
            mkdir(dirname($tokenPath), 0700, true);
        }
        file_put_contents($tokenPath, json_encode($client->getAccessToken()));
    }
    return $client;
}

// Autoload Composer.
require_once 'C:\xampp\vendor\autoload.php';

$client = getClient();

$service = new Google_Service_Sheets($client);

// The ID of the spreadsheet to retrieve data from.
$spreadsheetId = '1JYK5ckijfCUds-uhU0qpCOtDim8HO6CPzzX9GSit0BU';  // TODO: Update placeholder value.


// The A1 notation of the values to retrieve.
$range = 'TrafficData!A1:C';  // TODO: Update placeholder value.

$TrafficDataresponse = $service->spreadsheets_values->get($spreadsheetId, $range);





?>




<!doctype html>
<html lang="en">

<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-giJF6kkoqNQ00vy+HMDP7azOuL0xtbfIcaT9wjKHr8RbDVddVHyTfAAsrekwKmP1" crossorigin="anonymous">
    <link href="style.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>


    <title>SIOT</title>
<script>
    function AutoRefresh( t ) {
               setTimeout("location.reload(true);", t);
    }
               </script>

</head>

<body  onload = "JavaScript:AutoRefresh(2000);">
    <header class="bg-dark">

        <div class="container">
            <nav class="navbar navbar-expand-md navbar-dark bg-dark">
                <a class="navbar-brand" href="#">SIOT Coursework</a>
                <button class="navbar-toggler" type="button" data-toggle="collapse"
                    data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false"
                    aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                </button>

                <div class="collapse navbar-collapse" id="navbarSupportedContent">
                    <ul class="navbar-nav mr-auto">
                        <li class="nav-item active">
                            <a class="nav-link" onclick="menuSelection('home');">Home</a>
                        </li>
                        <li class="nav-item active">
                            <a class="nav-link" onclick="menuSelection('liveData');">Live Data </a>
                        </li>
                        <li class="nav-item active">
                            <a class="nav-link" onclick="menuSelection('historicData');">Historic Data </a>
                        </li>
                        <li class="nav-item active">
                            <a class="nav-link" onclick="menuSelection('correlation');">Correlations</a>
                        </li>
                        <li class="nav-item active">
                            <a class="nav-link" onclick="menuSelection('rawData');">Raw Data</a>
                        </li>
                    </ul>
                </div>
            </nav>
        </div>
    </header>

     <div class="section" id="liveData">
        <div class="container pt-5">
            <h1>Live Data</h1>

<div class="row border border-3 bg-light">
<h3>Latest information</h3>
<p class="fst-italic">Last Updated on 10/01/2021 at 9:59:07</p>
<p>According to <a href="http://OpenWeatherMap.org">OpenWeatherMap.org</a>, London currently has haze and it is -0.46&#176;C.</p>
<p>At the balcony at Hackbridge, it is currently daytime and the temperature is 0&#176;C.</p>
<p>Over the past 5 mins, 10 vehicles have travelled via Hackbridge on A237 London Road.</p>

</div>

<h3 class="py-4">View the latest car data plotted </h3>


            <canvas id="myChart"></canvas>


        </div>
    </div>


    <!-- Optional JavaScript; choose one of the two! -->

    <!-- Option 1: Bootstrap Bundle with Popper -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-ygbV9kiqUc6oa4msXn9868pTtWMgiQaeYH7/t7LECLbyPA2x65Kgf80OJFdroafW" crossorigin="anonymous">
    </script>

    <!-- Option 2: Separate Popper and Bootstrap JS -->
    <!--
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.4/dist/umd/popper.min.js" integrity="sha384-q2kxQ16AaE6UbzuKqyBE9/u/KzioAlnx2maXQHiDX9d4/zp8Ok3f+M7DPm+Ib6IU" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/js/bootstrap.min.js" integrity="sha384-pQQkAEnwaBkjpqZ8RU1fF1AKtTcHJwFl3pblpTlHXybJjHpMYo79HY3hIi4NKxyj" crossorigin="anonymous"></script>
    -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.29.1/moment.min.js"
        integrity="sha512-qTXRIMyZIFb8iQcfjXWCO8+M5Tbc38Qi5WzdPOYZHIlZpzBHG3L3by84BBBOiRGiEb7KKtAOAs5qYdUiZiQNNQ=="
        crossorigin="anonymous"></script>

    <script src="https://cdn.jsdelivr.net/npm/chart.js@2.8.0"></script>

    <script>

// General




<?php

$TrafficDataresponseTime=[];
$TrafficDataresponseCars=[];


$numRowsTraffic = count($TrafficDataresponse->values);


for ($x=$numRowsTraffic-20; $x < $numRowsTraffic ; $x++) {
  array_push($TrafficDataresponseTime, $TrafficDataresponse->values[$x][0]);
  array_push($TrafficDataresponseCars, $TrafficDataresponse->values[$x][1]);
}


$temp_array = json_encode($TrafficDataresponseTime);
echo "var oriTrafficDataresponseTime = ". $temp_array . ";\n";

$temp_array = json_encode($TrafficDataresponseCars, JSON_NUMERIC_CHECK);
echo "var oriTrafficDataresponseCars = ". $temp_array . ";\n";


?>


    var oricustomDateTimeTraffic = [];
    var orimomcustomDateTimeTraffic = [];


    oriTrafficDataresponseTime = oriTrafficDataresponseTime.slice(oriTrafficDataresponseTime.length-10)

    for (var i = oriTrafficDataresponseTime.length-10; i < oriTrafficDataresponseTime.length; i++) {
        oricustomDateTimeTraffic[i] = new Date(parseInt(oriTrafficDataresponseTime[i].substring(4, 8)), parseInt(
            oriTrafficDataresponseTime[i].substring(2, 4)) - 1, parseInt(oriTrafficDataresponseTime[i]
            .substring(0, 2)), parseInt(oriTrafficDataresponseTime[i].substring(9, 11)), parseInt(
            oriTrafficDataresponseTime[i].substring(11, 13)), parseInt(oriTrafficDataresponseTime[i].substring(
            13, 15)));
        orimomcustomDateTimeTraffic[i] = moment(oricustomDateTimeTraffic[i]).format('DD/MM HH:mm:ss');
    }

// Live Data Numbers:
TrafficDataresponseCars = oriTrafficDataresponseCars.slice(oriTrafficDataresponseCars.length-10)

// document.getElementById('liveDataLastDate').innerHTML = oriWeatherAPIDataresponseDate[oriWeatherAPIDataresponseDate.length-1];
// document.getElementById('liveDataLastTime').innerHTML = oriWeatherAPIDataresponseTime[oriWeatherAPIDataresponseTime.length-1];
// document.getElementById('liveDataLastWeather').innerHTML = oriWeatherAPIDataresponseDesc[oriWeatherAPIDataresponseDesc.length-1];
// document.getElementById('liveDataLastAPITemp').innerHTML = oriWeatherAPIDataresponseTemp[oriWeatherAPIDataresponseTemp.length-1];
// document.getElementById('liveDataLastHackTemp').innerHTML = oriHackbridgeTempDataresponseTemp[oriHackbridgeTempDataresponseTemp.length-1];
// document.getElementById('liveDataLastCars').innerHTML = 37;
// document.getElementById('liveDataLastHackDay').innerHTML = oriTrafficDataresponseDay[oriTrafficDataresponseDay.length-1];

var ctx = document.getElementById('myChart').getContext('2d');
    var chart = new Chart(ctx, {

      type: 'line',

data: {
    labels: orimomcustomDateTimeTraffic,

    datasets: [{
            
            label: 'Number of Cars',
            // backgroundColor: 'rgb(255, 99, 132)',
            borderColor: 'rgb(0, 0, 0)',
            data: TrafficDataresponseCars,
    }

    ],

},

options: {
    animation: {
        duration: 0
    },
    scales: {
        yAxes: [{
            ticks: {
                beginAtZero: true
            }
        }]
    }
}


});



    </script>
</body>

</html>