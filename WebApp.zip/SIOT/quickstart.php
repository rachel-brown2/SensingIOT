<?php
// require 'C:\xampp\vendor\autoload.php';

// if (php_sapi_name() != 'cli') {
//     throw new Exception('This application must be run on the command line.');
// }


function getClient()
{
    $client = new Google_Client();
    $client->setApplicationName('Google Sheets API PHP Quickstart');
    $client->setScopes(Google_Service_Sheets::SPREADSHEETS);
    $client->setAuthConfig(__DIR__ .'/credentials.json');
    $client->setAccessType('offline');
    $client->setPrompt('select_account consent');

    // Load previously authorized token from a file, if it exists.
    // The file token.json stores the user's access and refresh tokens, and is
    // created automatically when the authorization flow completes for the first
    // time.
    $tokenPath = 'token.json';
    if (file_exists($tokenPath)) {
        $accessToken = json_decode(file_get_contents($tokenPath), true);
        $client->setAccessToken($accessToken);
    }

    // If there is no previous token or it's expired.
    if ($client->isAccessTokenExpired()) {
        // Refresh the token if possible, else fetch a new one.
        if ($client->getRefreshToken()) {
            $client->fetchAccessTokenWithRefreshToken($client->getRefreshToken());
        } else {
            // Request authorization from the user.
            $authUrl = $client->createAuthUrl();
            printf("Open the following link in your browser:\n%s\n", $authUrl);
            print 'Enter verification code: ';
            $authCode = trim(fgets(STDIN));

            // Exchange authorization code for an access token.
            $accessToken = $client->fetchAccessTokenWithAuthCode($authCode);
            $client->setAccessToken($accessToken);

            // Check to see if there was an error.
            if (array_key_exists('error', $accessToken)) {
                throw new Exception(join(', ', $accessToken));
            }
        }
        // Save the token to a file.
        if (!file_exists(dirname($tokenPath))) {
            mkdir(dirname($tokenPath), 0700, true);
        }
        file_put_contents($tokenPath, json_encode($client->getAccessToken()));
    }
    return $client;
}

// Autoload Composer.
require_once 'C:\xampp\vendor\autoload.php';

$client = getClient();

$service = new Google_Service_Sheets($client);

// The ID of the spreadsheet to retrieve data from.
$spreadsheetId = '1JYK5ckijfCUds-uhU0qpCOtDim8HO6CPzzX9GSit0BU';  // TODO: Update placeholder value.

// The A1 notation of the values to retrieve.
$range = 'WeatherAPIData!A1:D';  // TODO: Update placeholder value.

$WeatherAPIDataresponse = $service->spreadsheets_values->get($spreadsheetId, $range);

// The A1 notation of the values to retrieve.
$range = 'HackbridgeTemperatureData!A1:C';  // TODO: Update placeholder value.

$HackbridgeTempDataresponse = $service->spreadsheets_values->get($spreadsheetId, $range);



// TODO: Change code below to process the `response` object:
// echo '<pre>', var_export($response, true), '</pre>', "\n";

?>



<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-giJF6kkoqNQ00vy+HMDP7azOuL0xtbfIcaT9wjKHr8RbDVddVHyTfAAsrekwKmP1" crossorigin="anonymous">

    <title>Hello, world!</title>
  </head>
  <body>
    <h1>Hello, world!</h1>

    <table class="table">
    <tbody>

    <?php 
    
    for ($x=0; $x < count($WeatherAPIDataresponse->values); $x++) {
        echo('<tr>');
        echo('<td>'.$WeatherAPIDataresponse->values[$x][0].'</th>'); 
        echo('<td>'.$WeatherAPIDataresponse->values[$x][1].'</th>'); 
        echo('<td>'.$WeatherAPIDataresponse->values[$x][2].'</th>'); 
        echo('<td>'.$WeatherAPIDataresponse->values[$x][3].'</th>'); 
        echo('<td>'.$HackbridgeTempDataresponse->values[$x][1].'</th>'); 
        echo('</tr>');

    }


     
    ?>
      </tbody>

    </table>

    <canvas id="myChart"></canvas>

    <!-- Optional JavaScript; choose one of the two! -->

    <!-- Option 1: Bootstrap Bundle with Popper -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/js/bootstrap.bundle.min.js" integrity="sha384-ygbV9kiqUc6oa4msXn9868pTtWMgiQaeYH7/t7LECLbyPA2x65Kgf80OJFdroafW" crossorigin="anonymous"></script>

    <!-- Option 2: Separate Popper and Bootstrap JS -->
    <!--
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.4/dist/umd/popper.min.js" integrity="sha384-q2kxQ16AaE6UbzuKqyBE9/u/KzioAlnx2maXQHiDX9d4/zp8Ok3f+M7DPm+Ib6IU" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/js/bootstrap.min.js" integrity="sha384-pQQkAEnwaBkjpqZ8RU1fF1AKtTcHJwFl3pblpTlHXybJjHpMYo79HY3hIi4NKxyj" crossorigin="anonymous"></script>
    -->
    <script src="https://cdn.jsdelivr.net/npm/chart.js@2.8.0"></script>

    <script>
    
    var ctx = document.getElementById('myChart').getContext('2d');
var chart = new Chart(ctx, {
    // The type of chart we want to create
    type: 'line',

    // The data for our dataset
    data: {
        labels: 
        <?php 
            $numRows = 30;
             echo('[');
            //  for ($x=1; $x < count($response->values) ; $x++) {
                for ($x=1; $x < $numRows ; $x++) {
             echo("'".$WeatherAPIDataresponse->values[$x][0]." ". $WeatherAPIDataresponse->values[$x][1]."',"); 
            }
            echo("'".$WeatherAPIDataresponse->values[$numRows-1][0].' '.$WeatherAPIDataresponse->values[$numRows-1][1]."'"); 
            echo('],');
            
            ?>
        
        // ['January', 'February', 'March', 'April', 'May', 'June', 'July'],
        datasets: [{
            label: 'Weather API',
            // backgroundColor: 'rgb(255, 99, 132)',
            borderColor: 'rgb(255, 99, 132)',
            data: <?php 
             echo('[');
            //  for ($x=1; $x < count($response->values) ; $x++) {
                for ($x=1; $x < $numRows ; $x++) {


             echo($WeatherAPIDataresponse->values[$x][3].','); 
            }
            echo($WeatherAPIDataresponse->values[$numRows-1][3]); 

            echo(']');
            
            ?>
        },
        {
            label: 'Hackbridge Sensor',
            // backgroundColor: 'rgb(255, 99, 132)',
            borderColor: 'rgb(255, 99, 0)',
            data: <?php 
             echo('[');
            //  for ($x=1; $x < count($response->values) ; $x++) {
                for ($x=1; $x < $numRows ; $x++) {


             echo($HackbridgeTempDataresponse->values[$x][1].','); 
            }
            echo($HackbridgeTempDataresponse->values[$numRows-1][1]); 

            echo(']');
            
            ?>
        }
        
        ]
    },

    // Configuration options go here
    options: {}
});
    
    
    </script>

  </body>
</html>
<html>

<b