<?php

function getClient()
{
    $client = new Google_Client();
    $client->setApplicationName('Google Sheets API PHP Quickstart');
    $client->setScopes(Google_Service_Sheets::SPREADSHEETS);
    $client->setAuthConfig(__DIR__ .'/credentials.json');
    $client->setAccessType('offline');
    $client->setPrompt('select_account consent');

    $tokenPath = 'token.json';
    if (file_exists($tokenPath)) {
        $accessToken = json_decode(file_get_contents($tokenPath), true);
        $client->setAccessToken($accessToken);
    }

    // If there is no previous token or it's expired.
    if ($client->isAccessTokenExpired()) {
        // Refresh the token if possible, else fetch a new one.
        if ($client->getRefreshToken()) {
            $client->fetchAccessTokenWithRefreshToken($client->getRefreshToken());
        } else {
            // Request authorization from the user.
            $authUrl = $client->createAuthUrl();
            printf("Open the following link in your browser:\n%s\n", $authUrl);
            print 'Enter verification code: ';
            $authCode = trim(fgets(STDIN));

            // Exchange authorization code for an access token.
            $accessToken = $client->fetchAccessTokenWithAuthCode($authCode);
            $client->setAccessToken($accessToken);

            // Check to see if there was an error.
            if (array_key_exists('error', $accessToken)) {
                throw new Exception(join(', ', $accessToken));
            }
        }
        // Save the token to a file.
        if (!file_exists(dirname($tokenPath))) {
            mkdir(dirname($tokenPath), 0700, true);
        }
        file_put_contents($tokenPath, json_encode($client->getAccessToken()));
    }
    return $client;
}

// Autoload Composer.
require_once 'C:\xampp\vendor\autoload.php';

$client = getClient();

$service = new Google_Service_Sheets($client);

// The ID of the spreadsheet to retrieve data from.
$spreadsheetId = '1JYK5ckijfCUds-uhU0qpCOtDim8HO6CPzzX9GSit0BU';  // TODO: Update placeholder value.

// The A1 notation of the values to retrieve.
$range = 'WeatherAPIData!A1:D';  // TODO: Update placeholder value.

$WeatherAPIDataresponse = $service->spreadsheets_values->get($spreadsheetId, $range);

// The A1 notation of the values to retrieve.
$range = 'HackbridgeTemperatureData!A1:C';  // TODO: Update placeholder value.

$HackbridgeTempDataresponse = $service->spreadsheets_values->get($spreadsheetId, $range);

// The A1 notation of the values to retrieve.
$range = 'TrafficData!A1:C';  // TODO: Update placeholder value.

$TrafficDataresponse = $service->spreadsheets_values->get($spreadsheetId, $range);





?>




<!doctype html>
<html lang="en">

<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-giJF6kkoqNQ00vy+HMDP7azOuL0xtbfIcaT9wjKHr8RbDVddVHyTfAAsrekwKmP1" crossorigin="anonymous">
    <link href="style.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>


    <title>SIOT</title>
</head>

<body>
    <header class="bg-dark">

        <div class="container">
            <nav class="navbar navbar-expand-md navbar-dark bg-dark">
                <a class="navbar-brand" href="#">SIOT Coursework</a>
                <button class="navbar-toggler" type="button" data-toggle="collapse"
                    data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false"
                    aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                </button>

                <div class="collapse navbar-collapse" id="navbarSupportedContent">
                    <ul class="navbar-nav mr-auto">
                        <li class="nav-item active">
                            <a class="nav-link" onclick="menuSelection('home');">Home</a>
                        </li>
                        <li class="nav-item active">
                            <a class="nav-link" onclick="menuSelection('liveData');">Live Data </a>
                        </li>
                        <li class="nav-item active">
                            <a class="nav-link" onclick="menuSelection('historicData');">Historic Data </a>
                        </li>
                        <li class="nav-item active">
                            <a class="nav-link" onclick="menuSelection('correlation');">Correlations</a>
                        </li>
                        <li class="nav-item active">
                            <a class="nav-link" onclick="menuSelection('rawData');">Data Table</a>
                        </li>
                    </ul>
                </div>
            </nav>
        </div>
    </header>

    <div class="section" id="home">

        <div style="height: calc(100vh - 55px); background: url(home.jpg);   background-size: cover;">


            <div class="container p-4" style="background-color:rgba(255, 255, 255, 0.6);">

                <p class="">According to <a href="http://OpenWeatherMap.org">OpenWeatherMap.org</a>, London's
                    temperature is <span id="liveDataLastAPITemp"></span>&#176;C. Based on past data, it is predicted
                    that <span id="homePageCars"></span> vehicles will be travelling via Hackbridge on A237 London Road.
                </p>

                <h3>Introduction</h3>
                <p>Having recently moved to a new house in Hackbridge, a small but well-connected village in the south
                    of London, and having also recently purchased a car, I wanted to use my IOT project to explore what
                    external factors would affect the traffic of the roads in the local area. From personal experience I
                    know that benefits of driving include the car providing a warm and drier environment compared to
                    public transport, therefore I hypothesised others might feel the same, and there might be a
                    correlation between temperature, weather, and the number of cars on the road. I expected that when
                    it was colder than the number of cars on the road would increase. </p>

            </div>

        </div>


        <div class="container">
        </div>

    </div>
    </div>



    <div class="section" style="display:none;" id="liveData">
        <div class="container pt-5">
            <h1>Live Data</h1>

            <div class="row border border-3 bg-light">
                <h3>Latest information</h3>
                <p class="fst-italic">Last Updated on <span id="liveDataLastDate"></span> at <span
                        id="liveDataLastTime"></span></p>
                <p>According to <a href="http://OpenWeatherMap.org">OpenWeatherMap.org</a>, London currently has <span
                        id="liveDataLastWeather"></span> and it is <span id="liveDataLastAPITemp"></span>&#176;C.</p>
                <p>At the balcony at Hackbridge, it is currently <span class="text-lowercase"
                        id="liveDataLastHackDay"></span>time and the temperature is <span
                        id="liveDataLastHackTemp"></span>&#176;C.</p>
                <p>Over the past 5 mins, <span id="liveDataLastCars"></span> vehicles have travelled via Hackbridge on
                    A237 London Road.</p>

            </div>

            <h3 class="py-4">View the latest temperature and car data plotted </h3>


            <canvas id="myChart"></canvas>

            <div class="row">
                <div class="col"><button type="button" onclick="last120()" class="btn w-100 btn-outline-primary">Last 2
                        hours</button>
                </div>
                <div class="col"><button type="button" onclick="last60()" class="btn w-100 btn-outline-primary">Last 1
                        hour</button>
                </div>
                <div class="col"><button type="button" onclick="last30()" class="btn w-100 btn-outline-primary">Last 30
                        mins</button>
                </div>

            </div>

            <div class="row mt-3">

                <div class="col-5">
                    <p>Or enter your desired time range in minutes</p>
                </div>
                <div class="col"><input type="text" id="customTime" class="form-control"></div>
                <div class="col"><button type="button" class="btn btn-outline-primary" onclick="lastcustom()">Update
                        Chart</button></div>

            </div>
        </div>
    </div>

    <div class="section" style="display:none;" id="historicData">
        <div class="container pt-5">
            <h1>Historic Data</h1>
            <canvas id="myCharthistoric"></canvas>

            <form id="historicDateForm">
                <div class="row">

                    <div class="col">
                        <div class="form-group">
                            <label for="historicDataFromDate">From:</label>
                            <select class="form-control" id="historicDataFromDate">
                                <option value="02" selected="selected">02 Jan 2021</option>
                                <option value="03">03 Jan 2021</option>
                                <option value="04">04 Jan 2021</option>
                                <option value="05">05 Jan 2021</option>
                                <option value="06">06 Jan 2021</option>
                                <option value="07">07 Jan 2021</option>
                                <option value="08">08 Jan 2021</option>
                            </select>
                        </div>
                    </div>


                    <div class="col">
                        <div class="form-group">
                            <label for="historicDataToDate">To:</label>
                            <select class="form-control" id="historicDataToDate">
                                <option value="02">02 Jan 2021</option>
                                <option value="03">03 Jan 2021</option>
                                <option value="04">04 Jan 2021</option>
                                <option value="05">05 Jan 2021</option>
                                <option value="06">06 Jan 2021</option>
                                <option value="07">07 Jan 2021</option>
                                <option value="08">08 Jan 2021</option>
                                <option value="09">09 Jan 2021</option>
                                <option value="10" selected="selected">10 Jan 2021</option>

                            </select>
                        </div>
                    </div>

                    <div class="col"><button style="height:100%" type="button" onclick="historicDateSelect()"
                            class="btn w-100 btn-outline-primary">Submit</button>
                    </div>


                </div>
            </form>
        </div>

    </div>

    <div class="section" style="display:none;" id="correlation">
        <div class="container pt-5">


            <h1>Correlations</h1>
            <h5>General Observations</h5>

            <p>
                The signal, trend, residual, and seasonal graphs were all plotted against time for the Hackbridge
                Temperature sensor, Weather API and Traffic data. They show a general trend to colder temperatures and a
                general increase in car usage towards the end of the data collection period. It shows that the busiest
                day for the number of cars was the 8th January and the coldest day was also the 8th. There were also a
                few abrupt changes, within all sets of data, which could likely be explained by glitches in the data
                collection. </p>
            <h5>Seasonality</h5>

            <p>A seasonality analysis was carried on in Correlation.py, using the seasonal_decompose function. This
                function required the period of the data which was set at the number of data points divided by the
                number of days within the dataset. The analysis showed that the temperature did tend get warmer in the
                first 1/3 -1/2 of each day and then cool off. This trend was more obviously seen in the Temperature API
                data rather than the Hackbridge API data, potentially because the DHT11 could only measure to the
                nearest oC. However, there was no seasonality seen within the traffic data.</p>

            <img src="HackbridgeTempSeason.png" alt="" class="img-fluid">

            <img src="WeatherAPISeason.png" alt="" class="img-fluid">
            <h5 class="mt-4">Regression Analysis</h5>


            <p>The API Temperature and the Hackbridge Temperature vs Traffic are the third are fourth most correlated
                features. Both show very weak correlation for when the temperature is colder more cars are on the road
                as shown by their regression graphs. However due to the weak correlation it suggests that the
                temperature is not the cause of people’s choice to drive past my flat in hack bridge. However, the API
                Temperature is more correlated than the Hackbridge temperature, this could be because of the potential
                bias discussed with the sensor above, or that the population are more likely to check the temperature of
                central London rather than their location when travelling.</p>

            <div class="row">

                <div class="col"><img src="regression.png" alt="" class="img-fluid">
                </div>

                <div class="col"><img src="regressionhackbridgetemp.png" alt="" class="img-fluid">
                </div>

            </div>

            <h5 class="mt-4">Pearson's Correlation</h5>


            <p>The Pearson’s correlation and the Linaer Regression showed mirroring results. This is positive as it
                implies that both of methods were applied correctly. However, both methods show that none of the data
                has a strong correlation. This could be because of several reasons, potentially because there was no
                correlation between the temperature, weather and car data collected but also possibly because the
                collection methods could have been improved such as collecting data over a longer period. This is
                because over a weeks’ worth of data, the weather especially temperature is likely to be reasonably
                similar, and therefore a year period may have been better to draw further insight.
            </p>

            <table class="table">
                <thead>
                    <tr>
                        <th scope="col">Variable A</th>
                        <th scope="col">Variable B</th>
                        <th scope="col">Pearson's Correlation</th>
                        <th scope="col">Coefficient of Determination</th>

                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td>Hackbridge Temperature</td>
                        <td>Temperature from API</td>
                        <td>0.717</td>
                        <td>0.514</td>

                    </tr>
                    <tr>
                        <td>Hackbridge Temperature</td>
                        <td>Number of Cars</td>
                        <td>-0.088</td>
                        <td>0.008</td>

                    </tr>
                    <tr>
                        <td>Temperature from API</td>
                        <td>Number of Cars</td>
                        <td>-0.158</td>
                        <td>0.025</td>

                    </tr>
                </tbody>
            </table>

        </div>
    </div>

    <div class="section" style="display:none;" id="rawData">
        <div class="container pt-5">
            <h1>Data Table</h1>

            <p id="rawDataText">Currently viewing the raw data | <u><a onclick="rawDataSelect('processed');">Click here
                        to view the processed data</a></u> </p>
            <p style="display:none;" id="ProcessedDataText">Currently viewing the processed data | <u><a
                        onclick="rawDataSelect('raw');">Click here to view the raw data</a></u> </p>

            <canvas id="myChartfull"></canvas>




            <div id="rawDataTable"></div>
            <div class="section" style="display:none;" id="processedDataTable"></div>



        </div>

    </div>




    </div>
    <!-- Optional JavaScript; choose one of the two! -->

    <!-- Option 1: Bootstrap Bundle with Popper -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-ygbV9kiqUc6oa4msXn9868pTtWMgiQaeYH7/t7LECLbyPA2x65Kgf80OJFdroafW" crossorigin="anonymous">
    </script>

    <!-- Option 2: Separate Popper and Bootstrap JS -->
    <!--
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.4/dist/umd/popper.min.js" integrity="sha384-q2kxQ16AaE6UbzuKqyBE9/u/KzioAlnx2maXQHiDX9d4/zp8Ok3f+M7DPm+Ib6IU" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/js/bootstrap.min.js" integrity="sha384-pQQkAEnwaBkjpqZ8RU1fF1AKtTcHJwFl3pblpTlHXybJjHpMYo79HY3hIi4NKxyj" crossorigin="anonymous"></script>
    -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.29.1/moment.min.js"
        integrity="sha512-qTXRIMyZIFb8iQcfjXWCO8+M5Tbc38Qi5WzdPOYZHIlZpzBHG3L3by84BBBOiRGiEb7KKtAOAs5qYdUiZiQNNQ=="
        crossorigin="anonymous"></script>

    <script src="https://cdn.jsdelivr.net/npm/chart.js@2.8.0"></script>

    <script>
    // Menu Bar

    function menuSelection(show) {

        var divsToHide = document.getElementsByClassName("section"); //divsToHide is an array
        for (var i = 0; i < divsToHide.length; i++) {
            divsToHide[i].style.display = "none"; // depending on what you're doing

            document.getElementById(show).style.display = 'block';

        }

    }

    // End Menu Bar

    // General




    <?php
$HackbridgeTempDataresponseDate = [];
$HackbridgeTempDataresponseTemp = [];
$HackbridgeTempDataresponseHumid = [];
$WeatherAPIDataresponseDate=[];
$WeatherAPIDataresponseTime=[];
$WeatherAPIDataresponseDesc=[];
$WeatherAPIDataresponseTemp=[];
$TrafficDataresponseTime=[];
$TrafficDataresponseCars=[];
$TrafficDataresponseDay=[];

$numRowsTemp = count($HackbridgeTempDataresponse->values);
$numRowsTraffic = count($TrafficDataresponse->values);


for ($x=1; $x < $numRowsTemp ; $x++) {
  array_push($HackbridgeTempDataresponseDate, $HackbridgeTempDataresponse->values[$x][0]);
  array_push($HackbridgeTempDataresponseTemp, $HackbridgeTempDataresponse->values[$x][1]);
  array_push($HackbridgeTempDataresponseHumid, $HackbridgeTempDataresponse->values[$x][2]);
  array_push($WeatherAPIDataresponseDate, $WeatherAPIDataresponse->values[$x][0]);
  array_push($WeatherAPIDataresponseTime, $WeatherAPIDataresponse->values[$x][1]);
  array_push($WeatherAPIDataresponseDesc, $WeatherAPIDataresponse->values[$x][2]);
  array_push($WeatherAPIDataresponseTemp, $WeatherAPIDataresponse->values[$x][3]);

}

for ($x=1; $x < $numRowsTraffic ; $x++) {
  array_push($TrafficDataresponseTime, $TrafficDataresponse->values[$x][0]);
  array_push($TrafficDataresponseCars, $TrafficDataresponse->values[$x][1]);
  array_push($TrafficDataresponseDay, $TrafficDataresponse->values[$x][2]);
}

$temp_array = json_encode($HackbridgeTempDataresponseDate);
echo "var oriHackbridgeTempDataresponseDate = ". $temp_array . ";\n";

$temp_array = json_encode($HackbridgeTempDataresponseTemp);
echo "var oriHackbridgeTempDataresponseTemp = ". $temp_array . ";\n";

$temp_array = json_encode($HackbridgeTempDataresponseHumid);
echo "var oriHackbridgeTempDataresponseHumid = ". $temp_array . ";\n";

$temp_array = json_encode($WeatherAPIDataresponseDate);
echo "var oriWeatherAPIDataresponseDate = ". $temp_array . ";\n";


$temp_array = json_encode($WeatherAPIDataresponseTime);
echo "var oriWeatherAPIDataresponseTime = ". $temp_array . ";\n";

$temp_array = json_encode($WeatherAPIDataresponseTemp);
echo "var oriWeatherAPIDataresponseTemp = ". $temp_array . ";\n";
$temp_array = json_encode($WeatherAPIDataresponseDesc);
echo "var oriWeatherAPIDataresponseDesc = ". $temp_array . ";\n";

$temp_array = json_encode($TrafficDataresponseTime);
echo "var oriTrafficDataresponseTime = ". $temp_array . ";\n";

$temp_array = json_encode($TrafficDataresponseCars);
echo "var oriTrafficDataresponseCars = ". $temp_array . ";\n";
$temp_array = json_encode($TrafficDataresponseDay);
echo "var oriTrafficDataresponseDay = ". $temp_array . ";\n";

?>

    var oricustomDateTime = [];
    var orimomcustomDateTime = [];
    var oricustomDateTimeTraffic = [];
    var orimomcustomDateTimeTraffic = [];
    var customDateTime = [];
    var WeatherAPIDataresponseTemp = [];
    var HackbridgeTempDataresponseTemp = [];

    for (var i = 0; i < oriHackbridgeTempDataresponseDate.length; i++) {
        oricustomDateTime[i] = new Date(oriWeatherAPIDataresponseDate[i].substr(6).concat("/").concat(
            oriWeatherAPIDataresponseDate[i].substr(3, 2).concat("/")).concat(oriWeatherAPIDataresponseDate[i]
            .substr(0, 2)).concat(" ").concat(oriWeatherAPIDataresponseTime[i]));
        orimomcustomDateTime[i] = moment(oricustomDateTime[i]).format('DD/MM HH:mm');
    }

    for (var i = 0; i < oriTrafficDataresponseTime.length; i++) {
        oricustomDateTimeTraffic[i] = new Date(parseInt(oriTrafficDataresponseTime[i].substring(4, 8)), parseInt(
            oriTrafficDataresponseTime[i].substring(2, 4)) - 1, parseInt(oriTrafficDataresponseTime[i]
            .substring(0, 2)), parseInt(oriTrafficDataresponseTime[i].substring(9, 11)), parseInt(
            oriTrafficDataresponseTime[i].substring(11, 13)), parseInt(oriTrafficDataresponseTime[i].substring(
            13, 15)));
        orimomcustomDateTimeTraffic[i] = moment(oricustomDateTimeTraffic[i]);
    }

    var oricarBin = []
    var oricarDayBin = []
    var tempCarIndex = 0
    var j

    for (var i = 0; i < oriHackbridgeTempDataresponseDate.length - 1; i++) {
        tempCounter = 0;
        binEndTime = oricustomDateTime[i + 1];
        oricarDayBin[i] = oriTrafficDataresponseDay[j]

        loop1: for (j = tempCarIndex; j < oriTrafficDataresponseCars.length; j++) {
            if (oricustomDateTimeTraffic[j] < binEndTime) {
                tempCounter = tempCounter + parseInt(oriTrafficDataresponseCars[j]);
            } else {
                tempCarIndex = j;
                break loop1;
            }
        }

        oricarBin[i] = tempCounter;

    }

    // End General

    // Live Data Numbers:

    document.getElementById('liveDataLastDate').innerHTML = oriWeatherAPIDataresponseDate[oriWeatherAPIDataresponseDate
        .length - 1];
    document.getElementById('liveDataLastTime').innerHTML = oriWeatherAPIDataresponseTime[oriWeatherAPIDataresponseTime
        .length - 1];
    document.getElementById('liveDataLastWeather').innerHTML = oriWeatherAPIDataresponseDesc[
        oriWeatherAPIDataresponseDesc.length - 1];
    document.getElementById('liveDataLastAPITemp').innerHTML = oriWeatherAPIDataresponseTemp[
        oriWeatherAPIDataresponseTemp.length - 1];
    document.getElementById('liveDataLastHackTemp').innerHTML = oriHackbridgeTempDataresponseTemp[
        oriHackbridgeTempDataresponseTemp.length - 1];
    document.getElementById('liveDataLastCars').innerHTML = oricarBin[oricarBin.length - 1];
    document.getElementById('liveDataLastHackDay').innerHTML = oriTrafficDataresponseDay[oriTrafficDataresponseDay
        .length - 1];






    // Historic Data 

    // Read CSV File

    $.ajax({
        url: 'LondonWeathervsTrafficData.csv',
        dataType: 'text',
    }).done(successFunction);


    var orihistcustomDateTime = [];
    var orihistmomcustomDateTime = [];
    var orihistmomcustomDateTimeplot = [];
    var orihistHackbridgeTemp = [];
    var orihistweatherAPI = [];
    var orihistweatherAPITemp = [];
    var orihistCar = [];
    var timeRef = new Date(2021, 0, 1);

    function successFunction(data) {
        var allRows = data.split(/\r?\n|\r/);

        var dataTablefromCSV = [];

        for (var i = 0; i < allRows.length; i++) {

            tempRow = allRows[i].split(",");
            orihistmomcustomDateTime[i] = moment(timeRef).add(tempRow[0], 's').toDate();

            orihistmomcustomDateTimeplot[i] = moment(timeRef).add(tempRow[0], 's').format('DD/MM HH:mm');
            orihistHackbridgeTemp[i] = parseFloat(tempRow[1]);
            orihistweatherAPI[i] = parseInt(tempRow[2]);
            orihistweatherAPITemp[i] = parseFloat(tempRow[3]);
            orihistCar[i] = parseInt(tempRow[4]);

        }

    }



    // window.onload = function (){


    // Raw Data Table
    var RawDataTableHeader =
        '<table class="table" style="text-transform: capitalize"><thead><tr><th scope="col">Date</th><th scope="col">Time</th><th scope="col">Weather Description from API</th><th scope="col">Temperature from API</th><th scope="col">Temperature from Sensor</th><th scope="col">Number of Cars</th><th scope="col">Day/Night</th></tr></thead><tbody>';
    var RawDataTableFooter = '  </tbody></table>';
    var RawDataTableContent = '';

    for (var i = 0; i < oriHackbridgeTempDataresponseDate.length - 1; i++) {
        // i=0;
        RawDataTableContent = RawDataTableContent.concat('<tr><td>'.concat(oriWeatherAPIDataresponseDate[i]).concat(
                '</td><td>').concat(oriWeatherAPIDataresponseTime[i]).concat('</td><td>').concat(
                oriWeatherAPIDataresponseDesc[i]).concat('</td><td>').concat(oriWeatherAPIDataresponseTemp[i])
            .concat('</td><td>').concat(oriHackbridgeTempDataresponseTemp[i]).concat('</td><td>').concat(oricarBin[
                i]).concat('</td><td>').concat(oricarDayBin[i]).concat('</td></tr>'));
    }

    document.getElementById("rawDataTable").innerHTML = RawDataTableHeader.concat(RawDataTableContent).concat(
        RawDataTableFooter);


    function histweatherAPIText(i) {
        var desc;

        switch (i) {
            case 1:
                desc = 'clear sky';
                break;
            case 2:
                desc = 'haze';
                break;
            case 3:
                desc = 'few clouds';
                break;
            case 4:
                desc = 'scattered clouds';
                break;
            case 5:
                desc = 'broken clouds';
                break;
            case 6:
                desc = 'overcast clouds';
                break;
            case 7:
                desc = 'mist';
                break;
            case 8:
                desc = 'fog';
                break;
            case 9:
                desc = 'light rain';
                break;
            case 10:
                desc = 'light intensity drizzle';
                break;
            case 11:
                desc = 'light intensity drizzle rain';
                break;
            case 12:
                desc = 'drizzle';
                break;
            case 13:
                desc = 'drizzle rain';
                break;
            case 14:
                desc = 'moderate rain';
                break;

            case 15:
                desc = 'light intensity shower rain';
                break;
            case 16:
                desc = 'shower rain';
                break;
            case 18:
                desc = 'smoke';
                break;
            case 19:
                desc = 'thunderstorm';
                break;
            case 20:
                desc = 'light snow';
                break;
        }
        return desc;

    }


    window.onload = function() {

        updateLiveDataChart(300);

        document.getElementById('homePageCars').innerHTML = Math.round((72.60269912 - 76.47340603) *
            oriWeatherAPIDataresponseTemp[oriWeatherAPIDataresponseTemp.length - 1] + 76.47340603);



        // var divsToHide = document.getElementsByClassName("section"); //divsToHide is an array
        //         for (var i = 0; i < divsToHide.length; i++) {
        //             divsToHide[i].style.display = "block"; // depending on what you're doing

        //             // document.getElementById(show).style.display = 'block';
        //         }


        var processedDataTableHeader =
            '<table class="table" style="text-transform: capitalize"><thead><tr><th scope="col">Datetime</th><th scope="col">Weather Description from API</th><th scope="col">Temperature from API</th><th scope="col">Temperature from Sensor</th><th scope="col">Number of Cars</th></tr></thead><tbody>';
        var processedDataTableFooter = '  </tbody></table>';
        var processedDataTableContent = '';





        for (var i = 0; i < 457 - 1; i++) {
            // i=0;
            processedDataTableContent = processedDataTableContent.concat('<tr><td>').concat(moment(
                    orihistmomcustomDateTime[i]).format('DD/MM/YYYY HH:mm:ss'))
                .concat('</td><td>').concat(
                    histweatherAPIText(orihistweatherAPI[i])).concat('</td><td>').concat(orihistweatherAPITemp[i])
                .concat('</td><td>').concat(orihistHackbridgeTemp[i]).concat('</td><td>').concat(orihistCar[i])
                .concat('</td></tr>');
        }

        document.getElementById("processedDataTable").innerHTML = processedDataTableHeader.concat(
                processedDataTableContent)
            .concat(
                processedDataTableFooter);



    };

    // Graphs


    var ctx = document.getElementById('myChart').getContext('2d');
    var chart = new Chart(ctx, {

        type: 'line',

        data: {
            labels: orimomcustomDateTime,

            datasets: [{
                    label: 'Temperature from Weather API',
                    // backgroundColor: 'rgb(255, 99, 132)',
                    borderColor: 'rgb(255, 99, 132)',
                    data: oriWeatherAPIDataresponseTemp,
                },
                {
                    label: 'Hackbridge Temperature',
                    // backgroundColor: 'rgb(255, 99, 132)',
                    borderColor: 'rgb(255, 99, 0)',
                    data: oriHackbridgeTempDataresponseTemp,
                },
                {
                    label: 'Number of Cars',
                    // backgroundColor: 'rgb(255, 99, 132)',
                    borderColor: 'rgb(0, 0, 0)',
                    data: oricarBin,
                }

            ],

        },
        options: {}
    });

    var ctxhist = document.getElementById('myCharthistoric').getContext('2d');

    var charthist = new Chart(ctxhist, {
        type: 'line',

        data: {
            labels: orihistmomcustomDateTimeplot,

            datasets: [{
                    label: 'Temperature from Weather API',
                    // backgroundColor: 'rgb(255, 99, 132)',
                    borderColor: 'rgb(255, 99, 132)',
                    data: orihistweatherAPITemp,
                },
                {
                    label: 'Hackbridge Temperature',
                    // backgroundColor: 'rgb(255, 99, 132)',
                    borderColor: 'rgb(255, 99, 0)',
                    data: orihistHackbridgeTemp,
                },
                {
                    label: 'Number of Cars',
                    // backgroundColor: 'rgb(255, 99, 132)',
                    borderColor: 'rgb(0, 0, 0)',
                    data: orihistCar,
                }

            ],

        },
        options: {}
    });


    var ctxfull = document.getElementById('myChartfull').getContext('2d');
    var chartfull = new Chart(ctxfull, {

        type: 'line',

        data: {
            labels: orimomcustomDateTime,

            datasets: [{
                    label: 'Temperature from Weather API',
                    // backgroundColor: 'rgb(255, 99, 132)',
                    borderColor: 'rgb(255, 99, 132)',
                    data: oriWeatherAPIDataresponseTemp,
                },
                {
                    label: 'Hackbridge Temperature',
                    // backgroundColor: 'rgb(255, 99, 132)',
                    borderColor: 'rgb(255, 99, 0)',
                    data: oriHackbridgeTempDataresponseTemp,
                },
                {
                    label: 'Number of Cars',
                    // backgroundColor: 'rgb(255, 99, 132)',
                    borderColor: 'rgb(0, 0, 0)',
                    data: oricarBin,
                }

            ],

        },
        options: {}
    });




    function updateLiveDataChart(lastMins) {

        // var lastMins = document.getElementById('demo').value;

        startIndex = oricustomDateTime.findIndex(n => n > new Date(oricustomDateTime[oricustomDateTime.length - 1] -
            lastMins * 60000));

        momcustomDateTime = orimomcustomDateTime.slice(startIndex);
        WeatherAPIDataresponseTemp = oriWeatherAPIDataresponseTemp.slice(startIndex);
        HackbridgeTempDataresponseTemp = oriHackbridgeTempDataresponseTemp.slice(startIndex);
        carBin = oricarBin.slice(startIndex);


        chart.data.labels = momcustomDateTime;
        chart.data.datasets[0].data = WeatherAPIDataresponseTemp;
        chart.data.datasets[1].data = HackbridgeTempDataresponseTemp;
        chart.data.datasets[2].data = carBin;
        // chart.options.scales.xAxes[0].time.unit = 'minutes';
        // chart.options.scales.xAxes[0].time.unitStepSize = 10;



        chart.update();
    }



    function last120() {
        updateLiveDataChart(120);
    }

    function last60() {
        updateLiveDataChart(60);
    }

    function last30() {
        updateLiveDataChart(30);
    }

    function lastcustom() {
        updateLiveDataChart(document.getElementById('customTime').value);
    }




    function updateHistoricDataChart(startDate, endDate) {


        startIndex = orihistmomcustomDateTime.findIndex(n => n > new Date('2021', '00', startDate));
        endIndex = orihistmomcustomDateTime.findIndex(n => n > new Date('2021', '00', endDate, 23, 59, 59));


        momcustomDateTimehist = orihistmomcustomDateTimeplot.slice(startIndex, endIndex);
        WeatherAPIDataresponseTemphist = orihistweatherAPITemp.slice(startIndex, endIndex);
        HackbridgeTempDataresponseTemphist = orihistHackbridgeTemp.slice(startIndex, endIndex);
        carBinhist = orihistCar.slice(startIndex, endIndex);


        charthist.data.labels = momcustomDateTimehist;
        charthist.data.datasets[0].data = WeatherAPIDataresponseTemphist;
        charthist.data.datasets[1].data = HackbridgeTempDataresponseTemphist;
        charthist.data.datasets[2].data = carBinhist;



        charthist.update();
    }


    function historicDateSelect() {
        var startDate = document.getElementById("historicDataFromDate");
        var endDate = document.getElementById("historicDataToDate");

        if (endDate.value < startDate.value) {
            tempDate = endDate;
            startDate = endDate;
            endDate = tempDate;
        }
        updateHistoricDataChart(startDate.value, endDate.value);

    }


    function rawDataSelect(i) {

        if (i == "raw") {
            document.getElementById('rawDataText').style.display = "block"; // depending on what you're doing
            document.getElementById('rawDataTable').style.display = 'block';
            document.getElementById('ProcessedDataText').style.display = 'none';
            document.getElementById('processedDataTable').style.display = 'none';
            chartfull.data.labels = orimomcustomDateTime;
            chartfull.data.datasets[0].data = oriWeatherAPIDataresponseTemp;
            chartfull.data.datasets[1].data = oriHackbridgeTempDataresponseTemp;
            chartfull.data.datasets[2].data = oricarBin;
            chartfull.update();

        } else {
            document.getElementById('rawDataText').style.display = "none"; // depending on what you're doing
            document.getElementById('rawDataTable').style.display = 'none';
            document.getElementById('ProcessedDataText').style.display = 'block';
            document.getElementById('processedDataTable').style.display = 'block';


            chartfull.data.labels = orihistmomcustomDateTimeplot;
            chartfull.data.datasets[0].data = orihistweatherAPITemp;
            chartfull.data.datasets[1].data = orihistHackbridgeTemp;
            chartfull.data.datasets[2].data = orihistCar;
            chartfull.update();

        }

    }
    </script>
</body>

</html>